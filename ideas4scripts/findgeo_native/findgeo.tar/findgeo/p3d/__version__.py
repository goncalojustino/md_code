#!/usr/bin/env python
# encoding: utf-8
# Copyright (c) 2009 Ch. Fufezan.
# module is distributed under the terms of the GNU General Public License
# See LICENSE for more details.


'''p3d version counter'''
__version__ = "0.4.2"