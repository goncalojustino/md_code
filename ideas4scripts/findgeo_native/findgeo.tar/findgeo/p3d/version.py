#
# version.py
#
# Copyright (C) C. Fufezan , All rights reserved
#
# $Id: version.py,0.1 C. Fufezan $
#
"""
p3d 
"""
__version__ = '0.4.2'

# which version file are we using now ...
